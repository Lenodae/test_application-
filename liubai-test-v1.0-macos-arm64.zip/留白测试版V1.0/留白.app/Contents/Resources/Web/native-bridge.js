(() => {
  "use strict";

  const handler = window.webkit?.messageHandlers?.native;
  const previewKey = "liubai-attention-timer-preview";
  let savedState = window.__nativeInitialState || null;
  if (!handler && !savedState) {
    try { savedState = JSON.parse(localStorage.getItem(previewKey) || "null"); }
    catch { savedState = null; }
  }

  function post(message) {
    if (handler) handler.postMessage(message);
  }

  function reportError(message) {
    const status = document.querySelector(".accessible-status");
    if (status) status.textContent = String(message);
  }

  let stateSaveSerial = 0;
  let acknowledgedState = savedState;
  let stateSaveQueue = Promise.resolve();
  let latestStateSave = stateSaveQueue;
  const stateSaveRequests = new Map();

  function writeState(requestId, state) {
    if (!handler) {
      localStorage.setItem(previewKey, JSON.stringify(state));
      return Promise.resolve();
    }
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        stateSaveRequests.delete(requestId);
        reject(new Error("记录保存未获确认，请重试。"));
      }, 10000);
      stateSaveRequests.set(requestId, { resolve, reject, timeout });
      try { post({ type: "save", requestId, state }); }
      catch (error) {
        clearTimeout(timeout);
        stateSaveRequests.delete(requestId);
        reject(error);
      }
    });
  }

  window.openai = {
    widgetState: savedState,
    setWidgetState(state) {
      try {
        const candidate = JSON.parse(JSON.stringify(state));
        const serial = ++stateSaveSerial;
        const requestId = `state-${serial}`;
        this.widgetState = candidate;
        const operation = stateSaveQueue.then(() => writeState(requestId, candidate));
        latestStateSave = operation.then(() => {
          acknowledgedState = candidate;
        }, error => {
          if (serial === stateSaveSerial) this.widgetState = acknowledgedState;
          throw error;
        });
        // Each caller receives its own failure; the queue itself remains usable.
        stateSaveQueue = latestStateSave.catch(() => {});
        return latestStateSave;
      } catch (error) {
        return Promise.reject(error);
      }
    }
  };

  let commandHandler = null;
  const pendingCommands = [];
  let lastStatus = "";
  let lastPhase = null;
  let lastCycle = null;
  let lastHeight = 0;
  let lastWidth = 0;
  let lastDragRegions = "";
  let resizeQueued = false;
  let preferenceSerial = 0;
  let preferences = { launchAtLogin: false, showOnLaunch: true, alwaysOnTop: true, visualReminder: true, soundReminder: false, widgetShortcut: "ctrl-alt-space", timerShortcut: "ctrl-alt-return", ...(window.__nativePreferences || {}) };
  const preferenceRequests = new Map();

  function updateDragRegions() {
    const root = document.getElementById("attention-timer");
    if (!root) return;
    function visibleRect(element) {
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      if (!element.getClientRects().length || rect.width <= 0 || rect.height <= 0 || style.visibility !== "visible" || style.display === "none") return null;
      return { x: rect.x, y: rect.y, width: rect.width, height: rect.height };
    }
    const areas = [...root.querySelectorAll(".timer-dial,.task-panel,.settings-titlebar,.analysis-titlebar")].map(visibleRect).filter(Boolean);
    const excluded = [...root.querySelectorAll("button,input,textarea,select,option,label,a,[contenteditable='true'],.ring-confirmation:not([hidden]),.task-history-list,.analysis-content")].map(visibleRect).filter(Boolean);
    const rings = [...root.querySelectorAll(".ring-adjust")].map(visibleRect).filter(Boolean).map(rect => ({ x: rect.x + rect.width / 2, y: rect.y + rect.height / 2, innerRadius: 86 * rect.width / 208, outerRadius: 110 * rect.width / 208 }));
    const message = { type: "dragRegions", areas, excluded, rings };
    const signature = JSON.stringify(message);
    if (signature !== lastDragRegions) {
      lastDragRegions = signature;
      post(message);
    }
  }

  function updateSize() {
    resizeQueued = false;
    const root = document.getElementById("attention-timer");
    if (!root) return;
    const analysisOpen = root.classList.contains("analysis-open");
    const settingsOpen = root.classList.contains("settings-open");
    const widePanel = (analysisOpen && root.classList.contains("analysis-zoomed")) || (settingsOpen && root.classList.contains("settings-zoomed"));
    const width = analysisOpen || settingsOpen ? (widePanel ? 920 : 720) : 506;
    const height = Math.max(278, Math.ceil(Math.max(root.scrollHeight, root.getBoundingClientRect().height)));
    if (height > 0 && (height !== lastHeight || width !== lastWidth)) {
      lastHeight = height;
      lastWidth = width;
      post({ type: "resize", width, height });
    }
    updateDragRegions();
  }

  function requestSize() {
    updateDragRegions();
    if (resizeQueued) return;
    resizeQueued = true;
    requestAnimationFrame(updateSize);
  }

  window.attentionNative = {
    isNative: Boolean(handler),
    resolveStateSave(result) {
      const requestId = String(result.requestId);
      const request = stateSaveRequests.get(requestId);
      if (!request) return;
      clearTimeout(request.timeout);
      stateSaveRequests.delete(requestId);
      if (result.ok === true) request.resolve();
      else request.reject(new Error(result.error || "记录未能保存，请重试。"));
    },
    async whenStateSaved() {
      // A completed deletion can enqueue its final live snapshot. Drain that
      // follow-up too before a caller reloads WebKit or quits the application.
      for (;;) {
        const current = latestStateSave;
        try { await current; }
        catch (error) { if (current === latestStateSave) throw error; }
        if (current === latestStateSave) return;
      }
    },
    getPreferences() { return { ...preferences }; },
    updatePreferences(value) {
      preferences = { ...preferences, ...value };
      window.dispatchEvent(new CustomEvent("attention:native-preferences", { detail: { ...preferences } }));
    },
    savePreferences(value) {
      if (!handler) {
        preferences = { ...preferences, ...value };
        return Promise.resolve(preferences);
      }
      const requestId = String(++preferenceSerial);
      return new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          preferenceRequests.delete(requestId);
          reject(new Error("设置未能保存，请重试。"));
        }, 10000);
        preferenceRequests.set(requestId, { resolve, reject, timeout });
        post({ type: "preferences", requestId, preferences: value });
      });
    },
    resolvePreferences(result) {
      const request = preferenceRequests.get(String(result.requestId));
      if (!request) return;
      clearTimeout(request.timeout);
      preferenceRequests.delete(String(result.requestId));
      if (result.preferences) preferences = { ...preferences, ...result.preferences };
      if (result.ok) request.resolve({ ...preferences });
      else request.reject(new Error(result.error || "设置未能保存，请重试。"));
    },
    widgetAction(action) { post({ type: "widgetAction", action }); },
    command(action, detail) {
      if (commandHandler) return commandHandler(action, detail);
      pendingCommands.push([action, detail]);
      return null;
    },
    bindCommands(callback) {
      commandHandler = callback;
      for (const [action, detail] of pendingCommands.splice(0)) callback(action, detail);
    },
    reportError,
    updateStatus(view) {
      const value = {
        type: "status",
        running: view.running,
        phase: view.phase,
        remainingSeconds: view.remainingSeconds,
        task: view.task
      };
      const signature = JSON.stringify({ ...value, remainingSeconds: Math.floor(view.remainingSeconds) });
      if (signature !== lastStatus) {
        post(value);
        lastStatus = signature;
      }
      if (lastCycle === view.cycleStartMs && lastPhase && lastPhase !== view.phase) {
        if (view.phase === "recovery") post({ type: "notice", text: "还剩半小时，留给自己恢复。计时已暂停。" });
        if (view.phase === "exhausted") post({ type: "notice", text: "今天的注意力预算已用完，休息一下吧。" });
      }
      lastPhase = view.phase;
      lastCycle = view.cycleStartMs;
    }
  };

  document.addEventListener("DOMContentLoaded", () => {
    const root = document.getElementById("attention-timer");
    root.classList.remove("viz-dotted-background");
    const sizeObserver = new ResizeObserver(requestSize);
    for (const element of [root, ...root.querySelectorAll(".timer-dial,.task-panel,.task-editor")]) sizeObserver.observe(element);
    new MutationObserver(requestSize).observe(root, { subtree: true, attributes: true, attributeFilter: ["hidden", "class"] });
    window.addEventListener("resize", requestSize);
    window.addEventListener("scroll", requestSize, true);
    document.fonts.ready.then(requestSize);
    requestSize();
    root.addEventListener("pointerdown", event => {
      if (!handler || event.button !== 0 || !event.isPrimary) return;
      if (event.target.closest("button,input,textarea,select,option,label,a,[contenteditable='true'],.settings-panel,.analysis-panel,.ring-adjust,.ring-confirmation,.task-history-list")) return;
      event.preventDefault();
      post({ type: "drag" });
    });
    post({ type: "ready" });
    updateDragRegions();
  });
})();
