(function (scope) {
  "use strict";

  const DAY_MS = 24 * 60 * 60 * 1000;
  const RETENTION_MS = 30 * DAY_MS;
  const MAX_ENTRIES = 500;
  const MAX_RECENT = 20;
  const MAX_TIME = 8640000000000000;

  function validTime(value) {
    return typeof value === "number" && Number.isFinite(value) && value >= 0 && value < MAX_TIME;
  }

  function taskText(value) {
    if (typeof value !== "string") return "";
    return Array.from(value.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, "").trim()).slice(0, 120).join("");
  }

  function validSeconds(value, maximum) {
    return typeof value === "number" && Number.isFinite(value) && value >= 0 && value <= maximum;
  }

  function rangeWindow(range, nowMs, cycleStartMs, cycleEndMs) {
    if (range === "today") {
      if (!validTime(cycleStartMs) || cycleStartMs > nowMs) return null;
      const next = new Date(cycleStartMs);
      next.setDate(next.getDate() + 1);
      const endMs = validTime(cycleEndMs) && cycleEndMs > cycleStartMs && cycleEndMs - cycleStartMs <= 49 * 60 * 60 * 1000 ? cycleEndMs : next.getTime();
      return { startMs: cycleStartMs, endMs, visibleEndMs: Math.min(nowMs, endMs) };
    }
    const start = new Date(nowMs);
    start.setHours(0, 0, 0, 0);
    start.setDate(start.getDate() - (range === "week" ? 6 : 29));
    const end = new Date(nowMs);
    end.setHours(0, 0, 0, 0);
    end.setDate(end.getDate() + 1);
    return { startMs: start.getTime(), endMs: end.getTime(), visibleEndMs: nowMs };
  }

  function clippedEntry(entry, window) {
    if (entry.startMs === entry.endMs) {
      return entry.startMs >= window.startMs && entry.startMs <= window.visibleEndMs
        ? { ...entry, wasClipped: false } : null;
    }
    const startMs = Math.max(entry.startMs, window.startMs);
    const endMs = Math.min(entry.endMs, window.visibleEndMs);
    if (endMs <= startMs) return null;
    const ratio = (endMs - startMs) / (entry.endMs - entry.startMs);
    return { ...entry, startMs, endMs, focusSeconds: entry.focusSeconds * ratio, recoverySeconds: entry.recoverySeconds * ratio,
      wasClipped: startMs !== entry.startMs || endMs !== entry.endMs };
  }

  function cleanEntry(value, nowMs) {
    if (!value || typeof value !== "object" || !["focus", "recovery"].includes(value.phase)) return null;
    if (!validTime(value.startMs) || !validTime(value.endMs) || !validTime(value.cycleStartMs)
        || value.startMs < value.cycleStartMs || value.endMs < value.startMs
        || value.endMs > nowMs + 60000 || value.endMs < nowMs - RETENTION_MS) return null;
    if (!validSeconds(value.focusSeconds, 12600) || !validSeconds(value.recoverySeconds, 1800)
        || value.focusSeconds + value.recoverySeconds <= 0
        || (value.phase === "focus" && value.recoverySeconds !== 0)
        || (value.phase === "recovery" && value.focusSeconds !== 0)) return null;
    if (typeof value.id !== "string" || !/^[a-zA-Z0-9_-]{1,100}$/.test(value.id)) return null;
    return {
      id: value.id,
      task: taskText(value.task) || "未命名任务",
      phase: value.phase,
      cycleStartMs: value.cycleStartMs,
      startMs: value.startMs,
      endMs: value.endMs,
      focusSeconds: value.focusSeconds,
      recoverySeconds: value.recoverySeconds,
      source: value.source === "manual" ? "manual" : "mac"
    };
  }

  class Journal {
    constructor(saved, nowMs = Date.now()) {
      if (!validTime(nowMs)) throw new Error("任务记录需要有效的当前时间。");
      this._nowMs = nowMs;
      this._activeID = null;
      this._serial = 0;
      const source = saved && saved.version === 1 ? saved : {};
      const seenText = new Set();
      this._recent = (Array.isArray(source.recent) ? source.recent : [])
        .filter(item => item && validTime(item.at) && item.at <= nowMs + 60000)
        .map(item => ({ text: taskText(item.text), at: item.at }))
        .sort((a, b) => b.at - a.at)
        .filter(item => {
          if (!item.text || seenText.has(item.text)) return false;
          seenText.add(item.text);
          return true;
        }).slice(0, MAX_RECENT);
      const seenIDs = new Set();
      this._entries = (Array.isArray(source.entries) ? source.entries : [])
        .map(item => cleanEntry(item, nowMs))
        .filter(item => {
          if (!item || seenIDs.has(item.id)) return false;
          seenIDs.add(item.id);
          return true;
        });
      this._prune(nowMs);
    }

    _prune(nowMs) {
      if (validTime(nowMs)) this._nowMs = Math.max(this._nowMs, nowMs);
      this._entries = this._entries
        .filter(item => item.endMs >= this._nowMs - RETENTION_MS)
        .sort((a, b) => a.endMs - b.endMs || a.startMs - b.startMs)
        .slice(-MAX_ENTRIES);
      if (!this._entries.some(item => item.id === this._activeID)) this._activeID = null;
    }

    remember(text, nowMs = Date.now()) {
      const normalized = taskText(text);
      if (!normalized || !validTime(nowMs)) return false;
      this._recent = [{ text: normalized, at: nowMs }, ...this._recent.filter(item => item.text !== normalized)].slice(0, MAX_RECENT);
      return true;
    }

    recent() {
      return this._recent.map(item => ({ ...item }));
    }

    credit(event) {
      if (!event || !["focus", "recovery"].includes(event.phase)
          || !validSeconds(event.seconds, event.phase === "focus" ? 12600 : 1800) || event.seconds <= 0
          || !validTime(event.cycleStartMs) || !validTime(event.startMs) || !validTime(event.endMs)
          || event.startMs < event.cycleStartMs || event.endMs < event.startMs) return false;
      this._prune(event.endMs);
      if (event.endMs < this._nowMs - RETENTION_MS) return false;
      const task = taskText(event.task) || "未命名任务";
      const secondsKey = event.phase === "focus" ? "focusSeconds" : "recoverySeconds";
      const maximum = event.phase === "focus" ? 12600 : 1800;
      let entry = this._entries.find(item => item.id === this._activeID);
      if (!entry || entry.task !== task || entry.phase !== event.phase || entry.cycleStartMs !== event.cycleStartMs
          || event.startMs < entry.endMs - 1 || event.startMs - entry.endMs > 1500
          || entry[secondsKey] + event.seconds > maximum + 0.000001) {
        let id;
        do { id = `${Math.floor(event.cycleStartMs).toString(36)}-${Math.floor(event.startMs).toString(36)}-${++this._serial}`; }
        while (this._entries.some(item => item.id === id));
        entry = { id, task, phase: event.phase, cycleStartMs: event.cycleStartMs, startMs: event.startMs, endMs: event.endMs, focusSeconds: 0, recoverySeconds: 0, source: "mac" };
        this._entries.push(entry);
        this._activeID = id;
      }
      entry[secondsKey] += event.seconds;
      entry.endMs = Math.max(entry.endMs, event.endMs);
      this._prune(event.endMs);
      return true;
    }

    addManual(value, nowMs = Date.now()) {
      if (!validTime(nowMs)) throw new Error("请使用有效的当前时间。");
      const rawTask = typeof value?.task === "string" ? value.task.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, "").trim() : "";
      if (!rawTask || Array.from(rawTask).length > 120) throw new Error("请填写 1–120 个字的任务。");
      if (!["focus", "recovery"].includes(value.phase)) throw new Error("请选择专注或恢复。");
      const { cycleStartMs, startMs, endMs, phase } = value;
      if (![cycleStartMs, startMs, endMs].every(validTime) || startMs < cycleStartMs || endMs <= startMs) throw new Error("结束时间必须晚于开始时间，且开始时间不能早于当天刷新时间。");
      if (endMs > nowMs) throw new Error("不能补记未来的时间。");
      const retainedFrom = Math.max(nowMs, this._nowMs) - RETENTION_MS;
      if (startMs < retainedFrom) throw new Error("只能补记最近 30 天的时间。");
      const seconds = (endMs - startMs) / 1000;
      if (!validSeconds(seconds, phase === "focus" ? 12600 : 1800)) throw new Error(phase === "focus" ? "单段专注不能超过 3 小时 30 分钟。" : "单段恢复不能超过 30 分钟。");
      const overlaps = this._entries.some(entry => entry.startMs === entry.endMs
        ? startMs <= entry.startMs && endMs > entry.startMs
        : startMs < entry.endMs && endMs > entry.startMs);
      if (overlaps) throw new Error("这段时间与已有记录重叠，请调整起止时间。");
      if (this._entries.filter(entry => entry.endMs >= retainedFrom).length >= MAX_ENTRIES) throw new Error("记录已达到 500 段，请先删除不需要的记录。");
      let id;
      do { id = `manual-${Math.floor(cycleStartMs).toString(36)}-${Math.floor(startMs).toString(36)}-${++this._serial}`; }
      while (this._entries.some(entry => entry.id === id));
      const entry = { id, task: rawTask, phase, cycleStartMs, startMs, endMs,
        focusSeconds: phase === "focus" ? seconds : 0, recoverySeconds: phase === "recovery" ? seconds : 0, source: "manual" };
      this._entries.push(entry);
      this._prune(nowMs);
      return { ...entry };
    }

    stop() {
      this._activeID = null;
    }

    activeRecordID() {
      return this._activeID;
    }

    remove(id, { forgetRecent = true } = {}) {
      const index = this._entries.findIndex(item => item.id === id);
      if (index < 0) return null;
      const entry = this._entries[index];
      const removal = { entry: { ...entry }, recentBefore: this.recent(), wasActive: this._activeID === id, forgetRecent: Boolean(forgetRecent) };
      this._entries.splice(index, 1);
      if (removal.wasActive) this.stop();
      if (forgetRecent) this._recent = this._recent.filter(item => item.text !== entry.task);
      return removal;
    }

    restoreRemoval(removal) {
      const entry = cleanEntry(removal?.entry, this._nowMs);
      // A rollback must not replace newer records or exceed retention limits.
      if (!entry || this._entries.some(item => item.id === entry.id) || this._entries.length >= MAX_ENTRIES) return false;
      this._entries.push(entry);
      this._prune(this._nowMs);
      if (removal.forgetRecent && !this._recent.some(item => item.text === entry.task)) {
        const previous = (Array.isArray(removal.recentBefore) ? removal.recentBefore : [])
          .filter(item => item && taskText(item.text) === entry.task && validTime(item.at) && item.at <= this._nowMs + 60000)
          .sort((a, b) => b.at - a.at)[0];
        if (previous) {
          this._recent = [...this._recent, { text: entry.task, at: previous.at }]
            .sort((a, b) => b.at - a.at).slice(0, MAX_RECENT);
        }
      }
      // The deleted segment stays stopped; a newer running segment keeps its ID.
      return true;
    }

    records({ range = "today", sort = "recent", nowMs = this._nowMs, cycleStartMs, cycleEndMs } = {}) {
      this._prune(nowMs);
      const window = rangeWindow(range, this._nowMs, cycleStartMs, cycleEndMs);
      if (!window) return [];
      return this._entries.filter(item => range !== "today" || item.cycleStartMs === cycleStartMs)
        .map(item => clippedEntry(item, window)).filter(Boolean)
        .sort((a, b) => sort === "duration"
          ? (b.focusSeconds + b.recoverySeconds) - (a.focusSeconds + a.recoverySeconds) || b.endMs - a.endMs
          : b.endMs - a.endMs || b.startMs - a.startMs)
        .map(item => ({ ...item }));
    }

    histogram({ range = "today", nowMs = this._nowMs, cycleStartMs, cycleEndMs } = {}) {
      const rows = this.records({ range, nowMs, cycleStartMs, cycleEndMs });
      const window = rangeWindow(range, this._nowMs, cycleStartMs, cycleEndMs);
      if (!window) return [];
      const buckets = [];
      for (let startMs = window.startMs; startMs < window.endMs;) {
        const date = new Date(startMs);
        const next = new Date(startMs);
        if (range === "today") next.setTime(startMs + 60 * 60 * 1000);
        else next.setDate(next.getDate() + 1);
        const endMs = Math.min(window.endMs, next.getTime());
        buckets.push({ startMs, endMs,
          label: range === "today" ? `${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}` : `${date.getMonth() + 1}/${date.getDate()}`,
          focusSeconds: 0, recoverySeconds: 0, manualSeconds: 0, macSeconds: 0 });
        startMs = endMs;
      }
      for (const row of rows) {
        const spanMs = row.endMs - row.startMs;
        let portions;
        if (spanMs === 0) {
          const bucket = buckets.find(item => row.startMs >= item.startMs && row.startMs < item.endMs)
            || (row.startMs === window.endMs ? buckets[buckets.length - 1] : null);
          portions = bucket ? [[bucket, 1]] : [];
        } else {
          portions = buckets.map(bucket => [bucket, Math.max(0, Math.min(row.endMs, bucket.endMs) - Math.max(row.startMs, bucket.startMs)) / spanMs])
            .filter(([, ratio]) => ratio > 0);
        }
        let focusRemaining = row.focusSeconds, recoveryRemaining = row.recoverySeconds;
        portions.forEach(([bucket, ratio], index) => {
          const last = index === portions.length - 1;
          const focus = last ? focusRemaining : row.focusSeconds * ratio;
          const recovery = last ? recoveryRemaining : row.recoverySeconds * ratio;
          bucket.focusSeconds += focus;
          bucket.recoverySeconds += recovery;
          bucket[row.source === "manual" ? "manualSeconds" : "macSeconds"] += focus + recovery;
          focusRemaining -= focus;
          recoveryRemaining -= recovery;
        });
      }
      return buckets;
    }

    serialize() {
      return { version: 1, recent: this.recent(), entries: this._entries.map(item => ({ ...item })) };
    }
  }

  scope.AttentionTaskJournal = Object.freeze({ Journal, MAX_ENTRIES, MAX_RECENT, RETENTION_MS });
})(globalThis);
